package co.edu.eam.miprimeraapp.modelo

class Comentario {
}